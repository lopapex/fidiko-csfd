
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/lib/radar-refresh.ts
import { getStore as getStore2 } from "@netlify/blobs";

// netlify/lib/radar-csfd.ts
import { getStore } from "@netlify/blobs";
import { csfd } from "node-csfd-api";
var CACHE_STORE = "radar-csfd-cache";
var CACHE_VERSION = "v3";
var LOOKUP_CONCURRENCY = 4;
var LOOKUP_TIMEOUT_MS = 8e3;
var MATCHED_TTL_MS = 7 * 864e5;
var NOT_FOUND_TTL_MS = 864e5;
async function enrichRadarItemsWithCsfd(items) {
  const unique = /* @__PURE__ */ new Map();
  for (const item of items) {
    unique.set(`${item.mediaType}-${item.tmdbId}`, item);
  }
  const entries = [...unique.entries()];
  const matches = await mapConcurrent(entries, LOOKUP_CONCURRENCY, async ([key, item]) => [key, await loadMatch(item)]);
  const byItem = new Map(matches);
  return items.map((item) => {
    const match = byItem.get(`${item.mediaType}-${item.tmdbId}`) ?? null;
    const releaseDate = item.mediaType === "series" && item.channel === "streaming" ? match?.releaseDate ?? item.releaseDate : item.releaseDate;
    return {
      ...item,
      id: `${item.mediaType}-${item.tmdbId}-${item.channel}-${releaseDate}`,
      releaseDate,
      csfd: match
    };
  });
}
async function loadMatch(item) {
  const key = cacheKey(item);
  const store = getStore(CACHE_STORE, { consistency: "strong" });
  try {
    const cached2 = await store.get(key, { type: "json" });
    if (cached2 && isCachedRadarCsfdFresh(cached2)) {
      return cached2.match;
    }
  } catch (error) {
    console.warn(`Radar CSFD cache read failed for "${item.title}"`, error);
  }
  const result = await withTimeout(lookupMatch(item), LOOKUP_TIMEOUT_MS, { status: "error" });
  const cached = createCachedRadarCsfd(result);
  if (cached) {
    try {
      await store.setJSON(key, cached);
    } catch (error) {
      console.warn(`Radar CSFD cache write failed for "${item.title}"`, error);
    }
  }
  return result.status === "matched" ? result.match : null;
}
async function lookupMatch(item) {
  let failed = false;
  for (const query of [item.title, item.originalTitle].filter((value, index, values) => Boolean(value) && values.indexOf(value) === index)) {
    try {
      const result = await csfd.search(query);
      const candidates = item.mediaType === "series" ? [...result.tvSeries, ...result.movies] : [...result.movies, ...result.tvSeries];
      const match = selectCandidate(candidates, item, query);
      if (!match) continue;
      const details = await withTimeout(csfd.movie(match.id), LOOKUP_TIMEOUT_MS, null);
      const url = details?.url ?? match.url;
      if (!url) continue;
      return {
        status: "matched",
        match: {
          title: details?.title ?? match.title,
          rating: numberOrNull(details?.rating),
          ratingCount: numberOrNull(details?.ratingCount),
          url,
          releaseDate: selectCzechStreamingDate(details?.premieres ?? [], item)
        }
      };
    } catch (error) {
      failed = true;
      console.warn(`Radar CSFD lookup failed for "${query}"`, error);
    }
  }
  return failed ? { status: "error" } : { status: "not_found" };
}
function isCachedRadarCsfdFresh(entry, now = Date.now()) {
  const checkedAt = Date.parse(entry.checkedAt);
  if (!Number.isFinite(checkedAt)) return false;
  const ttl = entry.status === "matched" ? MATCHED_TTL_MS : NOT_FOUND_TTL_MS;
  return now - checkedAt <= ttl;
}
function createCachedRadarCsfd(result, checkedAt = (/* @__PURE__ */ new Date()).toISOString()) {
  if (result.status === "error") return null;
  return result.status === "matched" ? { status: "matched", checkedAt, match: result.match } : { status: "not_found", checkedAt, match: null };
}
function selectCzechStreamingDate(premieres, item) {
  if (item.mediaType !== "series" || item.channel !== "streaming") return null;
  const providerNames = item.providers.map((provider) => comparableTitle(provider.name));
  const vodPremieres = premieres.filter((premiere) => comparableTitle(premiere.format).includes("na vod"));
  const providerPremiere = vodPremieres.find((premiere) => {
    const company = comparableTitle(premiere.company);
    return providerNames.some((provider) => company.includes(provider) || provider.includes(company));
  });
  return providerPremiere?.date ?? (providerNames.length === 0 ? vodPremieres[0]?.date ?? null : null);
}
function selectCandidate(candidates, item, query) {
  const normalizedQuery = comparableTitle(query);
  const year = Number(item.releaseDate.slice(0, 4));
  return candidates.map((candidate) => ({ candidate, score: scoreCandidate(candidate, normalizedQuery, year, item.mediaType) })).filter(({ score }) => score >= 70).sort((left, right) => right.score - left.score)[0]?.candidate ?? null;
}
function scoreCandidate(candidate, query, year, mediaType) {
  const title = comparableTitle(candidate.title);
  if (!isPlausibleTitleMatch(title, query)) return -Infinity;
  let score = title === query ? 100 : 65;
  const yearDifference = Math.abs(candidate.year - year);
  score += yearDifference === 0 ? 40 : yearDifference === 1 ? 20 : -Math.min(50, yearDifference * 10);
  const isSeries = candidate.type === "series" || candidate.type === "tv-show" || candidate.type === "season";
  if (mediaType === "series" === isSeries) score += 20;
  return score;
}
function cacheKey(item) {
  return `${CACHE_VERSION}/${item.mediaType}/${item.releaseDate.slice(0, 4)}/${slugify(item.title)}`;
}
function comparableTitle(value) {
  return value.normalize("NFD").replace(new RegExp("\\p{Diacritic}", "gu"), "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
}
function isPlausibleTitleMatch(candidate, query) {
  if (!candidate || !query) return false;
  if (candidate === query || candidate.includes(query) || query.includes(candidate)) return true;
  const candidateWords = new Set(candidate.split(" ").filter((word) => word.length > 2));
  const queryWords = query.split(" ").filter((word) => word.length > 2);
  return queryWords.length > 0 && queryWords.filter((word) => candidateWords.has(word)).length / queryWords.length >= 0.75;
}
function slugify(value) {
  return comparableTitle(value).replace(/\s+/g, "-") || "title";
}
function numberOrNull(value) {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}
function withTimeout(promise, ms, fallback) {
  return new Promise((resolve) => {
    const timeout = setTimeout(() => resolve(fallback), ms);
    promise.then(resolve).catch(() => resolve(fallback)).finally(() => clearTimeout(timeout));
  });
}
async function mapConcurrent(items, concurrency, mapper) {
  const results = new Array(items.length);
  let index = 0;
  async function worker() {
    while (index < items.length) {
      const current = index++;
      results[current] = await mapper(items[current]);
    }
  }
  await Promise.all(Array.from({ length: Math.min(concurrency, items.length) }, worker));
  return results;
}

// netlify/lib/radar-providers.ts
var PROVIDERS = [
  {
    aliases: /^netflix$/,
    homepage: "https://www.netflix.com/cz/",
    searchUrl: (query) => `https://www.netflix.com/search?q=${query}`
  },
  {
    aliases: /^disney(?: plus)?$/,
    homepage: "https://www.disneyplus.com/cs-cz",
    searchUrl: (query) => `https://www.disneyplus.com/search?q=${query}`
  },
  {
    aliases: /^(?:amazon )?prime video(?: with ads)?$/,
    homepage: "https://www.primevideo.com/",
    searchUrl: (query) => `https://www.primevideo.com/search/ref=atv_nb_sr?phrase=${query}`
  },
  {
    aliases: /^apple tv(?: plus)?$/,
    homepage: "https://tv.apple.com/cz",
    searchUrl: (query) => `https://tv.apple.com/cz/search?term=${query}`
  },
  {
    aliases: /^(?:i?prima)(?: plus)?$/,
    homepage: "https://www.iprima.cz/",
    searchUrl: (query) => `https://www.iprima.cz/vyhledavani?query=${query}`
  },
  {
    aliases: /^(?:hbo )?max$/,
    homepage: "https://play.hbomax.com/",
    searchUrl: (query) => `https://play.hbomax.com/search/result?q=${query}`
  },
  {
    aliases: /^oneplay$/,
    homepage: "https://www.oneplay.cz/",
    searchUrl: (query) => `https://www.oneplay.cz/vyhledat?query=${query}`
  },
  {
    aliases: /^skyshowtime$/,
    homepage: "https://www.skyshowtime.com/cz"
  }
];
function isAllowedProvider(name) {
  return Boolean(findProvider(name));
}
function getProviderLink(name, title) {
  const provider = findProvider(name);
  if (!provider) return { url: null, linkType: void 0 };
  const searchTitle = normalizeSearchTitle(title);
  if (provider.searchUrl && searchTitle) {
    return {
      url: provider.searchUrl(encodeURIComponent(searchTitle)),
      linkType: "search"
    };
  }
  return { url: provider.homepage, linkType: "homepage" };
}
function findProvider(name) {
  const normalized = normalizeProviderName(name);
  return PROVIDERS.find((provider) => provider.aliases.test(normalized));
}
function normalizeSearchTitle(title) {
  return title?.replace(/\s*-\s*(?:série|serie|season)\s+\d+\s*$/iu, "").trim() || null;
}
function normalizeProviderName(name) {
  return name.normalize("NFD").replace(new RegExp("\\p{Diacritic}", "gu"), "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
}

// netlify/lib/radar-refresh.ts
var TMDB_API_BASE = "https://api.themoviedb.org/3";
var TMDB_IMAGE_BASE = "https://image.tmdb.org/t/p";
var RADAR_CACHE_STORE = "radar-cache";
var RADAR_CACHE_KEY = "current-v7";
var SCHEDULE_CACHE_STORE = "schedule-cache";
var SCHEDULE_CACHE_KEY = "current-v2";
var MAX_PAGES = 5;
var PROVIDER_CONCURRENCY = 6;
var REQUEST_TIMEOUT_MS = 12e3;
var REQUEST_ATTEMPTS = 3;
async function hasRadarCache() {
  const store = getStore2(RADAR_CACHE_STORE, { consistency: "strong" });
  return Boolean(await store.get(RADAR_CACHE_KEY));
}
async function refreshRadarCache() {
  const today = getPragueTodayISO();
  const rangeStart = startOfISOWeek(today);
  const rangeEnd = addDaysISO(today, 60);
  const store = getStore2(RADAR_CACHE_STORE, { consistency: "strong" });
  const previous = await readSnapshot(store, RADAR_CACHE_KEY);
  const snapshot = await buildRadarSnapshot(rangeStart, rangeEnd, previous);
  await store.setJSON(RADAR_CACHE_KEY, snapshot);
  return snapshot;
}
async function buildRadarSnapshot(rangeStart, rangeEnd, previous) {
  const totalStarted = performance.now();
  const token = process.env.TMDB_API_TOKEN?.trim();
  if (!token) {
    throw new Error("TMDB_API_TOKEN is not configured");
  }
  const discoveryStarted = performance.now();
  const [cinemaMovies, streamingMovies, streamingSeries, schedule] = await Promise.all([
    discoverMovies(token, rangeStart, rangeEnd, "2|3"),
    discoverMovies(token, rangeStart, rangeEnd, "4"),
    discoverSeries(token, rangeStart, rangeEnd),
    readScheduleCache()
  ]);
  const discoveryMs = performance.now() - discoveryStarted;
  const providersStarted = performance.now();
  const cinemaSource = {
    items: cinemaMovies.items.map((item) => createRadarItem(item, "movie", "cinema", null)),
    succeeded: cinemaMovies.succeeded
  };
  const movieStreamingSource = streamingMovies.succeeded ? await enrichStreamingItems(token, streamingMovies.items, "movie") : { items: [], succeeded: false };
  const resolvedSeries = streamingSeries.succeeded ? await resolveSeriesPremieres(token, streamingSeries.items.slice(0, 40), rangeStart, rangeEnd) : { items: [], succeeded: false };
  const seriesStreamingSource = resolvedSeries.succeeded ? await enrichStreamingItems(token, resolvedSeries.items, "series") : { items: [], succeeded: false };
  const providersMs = performance.now() - providersStarted;
  const builtAt = (/* @__PURE__ */ new Date()).toISOString();
  const cinema = resolveSource("cinemaMovies", cinemaSource, previous, rangeStart, rangeEnd, builtAt);
  const movies = resolveSource("streamingMovies", movieStreamingSource, previous, rangeStart, rangeEnd, builtAt);
  const series = resolveSource("streamingSeries", seriesStreamingSource, previous, rangeStart, rangeEnd, builtAt);
  const sources = {
    cinemaMovies: cinema.state,
    streamingMovies: movies.state,
    streamingSeries: series.state
  };
  if (Object.values(sources).every((source) => source.status === "failed")) {
    throw new Error("TMDb discovery is temporarily unavailable");
  }
  const csfdStarted = performance.now();
  const enrichedItems = await enrichRadarItemsWithCsfd(
    deduplicateItems([...cinema.items, ...movies.items, ...series.items])
  );
  const csfdMs = performance.now() - csfdStarted;
  const linkingStarted = performance.now();
  const items = linkProgramMatches(enrichedItems, schedule).sort(compareItems);
  const linkingMs = performance.now() - linkingStarted;
  const csfdMatches = items.filter((item) => item.csfd?.url).length;
  const programMatches = items.filter((item) => item.program).length;
  console.log("Radar refresh metrics", {
    rangeStart,
    rangeEnd,
    items: items.length,
    csfdMatches,
    missingCsfdMatches: items.length - csfdMatches,
    programMatches,
    scheduleCacheHit: Boolean(schedule),
    sources,
    timingsMs: {
      discovery: Math.round(discoveryMs),
      providers: Math.round(providersMs),
      csfd: Math.round(csfdMs),
      linking: Math.round(linkingMs),
      total: Math.round(performance.now() - totalStarted)
    }
  });
  return {
    fetchedAt: builtAt,
    range: { start: rangeStart, end: rangeEnd },
    sources,
    items
  };
}
async function readSnapshot(store, key) {
  try {
    return await store.get(key, { type: "json" });
  } catch (error) {
    console.warn(`Radar snapshot ${key} could not be read`, error);
    return null;
  }
}
function resolveSource(source, fresh, previous, rangeStart, rangeEnd, builtAt) {
  if (fresh.succeeded) {
    return {
      items: fresh.items,
      state: { status: "fresh", fetchedAt: builtAt }
    };
  }
  const canCarry = previous && rangeStart >= previous.range.start && rangeEnd <= previous.range.end;
  const carried = canCarry ? previous.items.filter((item) => belongsToSource(item, source) && item.releaseDate >= rangeStart && item.releaseDate <= rangeEnd) : [];
  const previousState = previous?.sources?.[source];
  return {
    items: carried,
    state: {
      status: carried.length > 0 ? "carried" : "failed",
      fetchedAt: carried.length > 0 ? previousState?.fetchedAt ?? previous?.fetchedAt ?? null : null
    }
  };
}
function belongsToSource(item, source) {
  if (source === "cinemaMovies") return item.mediaType === "movie" && item.channel === "cinema";
  if (source === "streamingMovies") return item.mediaType === "movie" && item.channel === "streaming";
  return item.mediaType === "series" && item.channel === "streaming";
}
async function discoverMovies(token, start, end, releaseType) {
  const params = new URLSearchParams({
    language: "cs-CZ",
    region: "CZ",
    sort_by: "release_date.asc",
    "release_date.gte": start,
    "release_date.lte": end,
    with_release_type: releaseType,
    include_adult: "false",
    include_video: "false"
  });
  try {
    return { items: await fetchDiscoverPages(token, "/discover/movie", params), succeeded: true };
  } catch (error) {
    console.warn(`TMDb ${releaseType === "4" ? "digital" : "regional cinema"} discovery failed for ${start} to ${end}`, error);
    return { items: [], succeeded: false };
  }
}
async function discoverSeries(token, start, end) {
  const baseParams = new URLSearchParams({
    language: "cs-CZ",
    "air_date.gte": start,
    "air_date.lte": end,
    include_adult: "false",
    include_null_first_air_dates: "false",
    watch_region: "CZ",
    with_watch_monetization_types: "flatrate|free|ads"
  });
  const results = await Promise.allSettled(["popularity.desc", "vote_count.desc"].map(async (sort) => {
    const params = new URLSearchParams(baseParams);
    params.set("sort_by", sort);
    return fetchDiscoverPages(token, "/discover/tv", params, 1);
  }));
  const fulfilled = results.filter((result) => result.status === "fulfilled");
  if (fulfilled.length === 0) {
    console.warn(`TMDb series discovery failed for ${start} to ${end}`, results.map((result) => result.status === "rejected" ? result.reason : null));
    return { items: [], succeeded: false };
  }
  const unique = /* @__PURE__ */ new Map();
  for (const result of fulfilled) {
    for (const item of result.value) unique.set(item.id, item);
  }
  return { items: [...unique.values()], succeeded: true };
}
async function resolveSeriesPremieres(token, candidates, start, end) {
  const resolved = await mapConcurrent2(candidates, PROVIDER_CONCURRENCY, async (candidate) => {
    try {
      const details = await tmdbFetch(token, `/tv/${candidate.id}?language=cs-CZ`);
      const seasons = (details.seasons ?? []).filter(
        (season) => season.season_number > 0 && Boolean(season.air_date) && season.air_date >= start && season.air_date <= end
      );
      return {
        succeeded: true,
        items: seasons.map((season) => ({
          ...candidate,
          name: `${details.name ?? candidate.name} - S\xE9rie ${season.season_number}`,
          original_name: `${details.original_name ?? candidate.original_name ?? candidate.name} - Season ${season.season_number}`,
          overview: details.overview ?? candidate.overview,
          poster_path: season.poster_path ?? details.poster_path ?? candidate.poster_path,
          first_air_date: season.air_date ?? void 0
        }))
      };
    } catch (error) {
      console.warn(`TMDb seasons for series ${candidate.id} were skipped`, error);
      return { succeeded: false, items: [] };
    }
  });
  return {
    items: resolved.flatMap((result) => result.items),
    succeeded: candidates.length === 0 || resolved.some((result) => result.succeeded)
  };
}
async function fetchDiscoverPages(token, path, baseParams, maxPages = MAX_PAGES) {
  const items = [];
  let totalPages = 1;
  for (let page = 1; page <= Math.min(totalPages, maxPages); page += 1) {
    const params = new URLSearchParams(baseParams);
    params.set("page", String(page));
    let response;
    try {
      response = await tmdbFetch(token, `${path}?${params}`);
    } catch (error) {
      if (page === 1) {
        throw error;
      }
      console.warn(`TMDb ${path} page ${page} was skipped after retries`, error);
      break;
    }
    items.push(...response.results);
    totalPages = Math.max(1, response.total_pages);
  }
  return items;
}
async function enrichStreamingItems(token, candidates, mediaType) {
  const enriched = await mapConcurrent2(candidates, PROVIDER_CONCURRENCY, async (item) => {
    let watch;
    try {
      watch = await tmdbFetch(
        token,
        mediaType === "movie" ? `/movie/${item.id}/watch/providers` : `/tv/${item.id}/watch/providers`
      );
    } catch (error) {
      console.warn(`TMDb providers for ${mediaType} ${item.id} were skipped`, error);
      return { succeeded: false, item: null };
    }
    const region = watch.results?.CZ;
    if (!region) {
      return { succeeded: true, item: null };
    }
    const title = mediaType === "movie" ? item.title : item.name;
    const providers = deduplicateProviders(
      [...region.flatrate ?? [], ...region.free ?? [], ...region.ads ?? []],
      title
    );
    if (providers.length === 0) {
      return { succeeded: true, item: null };
    }
    return {
      succeeded: true,
      item: createRadarItem(item, mediaType, "streaming", { providers, watchUrl: region.link ?? null })
    };
  });
  return {
    items: enriched.map((result) => result.item).filter((item) => item !== null),
    succeeded: candidates.length === 0 || enriched.some((result) => result.succeeded)
  };
}
function createRadarItem(item, mediaType, channel, streaming) {
  const title = mediaType === "movie" ? item.title : item.name;
  const originalTitle = mediaType === "movie" ? item.original_title : item.original_name;
  const releaseDate = mediaType === "movie" ? item.release_date : item.first_air_date;
  if (!title || !releaseDate) {
    throw new Error(`TMDb item ${item.id} is missing a title or release date`);
  }
  return {
    id: `${mediaType}-${item.id}-${channel}-${releaseDate}`,
    tmdbId: item.id,
    mediaType,
    channel,
    title,
    originalTitle: originalTitle && originalTitle !== title ? originalTitle : null,
    overview: item.overview?.trim() ?? "",
    posterUrl: item.poster_path ? `${TMDB_IMAGE_BASE}/w342${item.poster_path}` : null,
    releaseDate,
    providers: streaming?.providers ?? [],
    watchUrl: streaming?.watchUrl ?? null,
    csfd: null,
    program: null
  };
}
async function readScheduleCache() {
  try {
    const store = getStore2(SCHEDULE_CACHE_STORE, { consistency: "strong" });
    return await store.get(SCHEDULE_CACHE_KEY, { type: "json" });
  } catch (error) {
    console.warn("Radar could not read the Fidiko schedule cache", error);
    return null;
  }
}
function linkProgramMatches(items, schedule, now = getPragueNow()) {
  if (!schedule) return items;
  const byCsfdUrl = /* @__PURE__ */ new Map();
  const byTitle = /* @__PURE__ */ new Map();
  for (const film of schedule.films) {
    if (film.csfd?.url) byCsfdUrl.set(normalizeCsfdUrl(film.csfd.url), film);
    const title = normalizeMatchTitle(film.title);
    byTitle.set(title, [...byTitle.get(title) ?? [], film]);
  }
  return items.map((item) => {
    if (item.channel !== "cinema" || item.mediaType !== "movie") return item;
    const titleCandidates = byTitle.get(normalizeMatchTitle(item.title)) ?? [];
    const film = item.csfd?.url ? byCsfdUrl.get(normalizeCsfdUrl(item.csfd.url)) ?? uniqueFilm(titleCandidates.filter((candidate) => !candidate.csfd?.url)) : uniqueFilm(titleCandidates);
    if (!film) return item;
    const screeningDates = film.screenings.map((screening) => screening.dateISO).sort();
    const upcoming = film.screenings.filter((screening) => isUpcomingScreening(screening, now)).sort((left, right) => left.dateISO.localeCompare(right.dateISO) || (left.time ?? "99:99").localeCompare(right.time ?? "99:99"));
    if (upcoming.length === 0) return item;
    return {
      ...item,
      program: {
        filmId: film.id,
        firstScreeningDate: screeningDates[0],
        screeningCount: film.screenings.length,
        upcomingScreeningCount: upcoming.length,
        nextScreening: {
          dateISO: upcoming[0].dateISO,
          time: upcoming[0].time
        }
      }
    };
  });
}
function uniqueFilm(films) {
  return films.length === 1 ? films[0] : void 0;
}
function isUpcomingScreening(screening, now) {
  if (screening.dateISO > now.dateISO) return true;
  if (screening.dateISO < now.dateISO) return false;
  return !screening.time || screening.time >= now.time;
}
function normalizeCsfdUrl(value) {
  try {
    return new URL(value).pathname.replace(/\/$/, "");
  } catch {
    return value.replace(/[?#].*$/, "").replace(/\/$/, "");
  }
}
function normalizeMatchTitle(value) {
  return value.normalize("NFD").replace(new RegExp("\\p{Diacritic}", "gu"), "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
}
function deduplicateProviders(providers, title) {
  const unique = /* @__PURE__ */ new Map();
  for (const provider of providers) {
    unique.set(provider.provider_id, provider);
  }
  return [...unique.values()].filter((provider) => !isHiddenProvider(provider.provider_name)).sort((left, right) => left.display_priority - right.display_priority).map((provider) => ({
    id: provider.provider_id,
    name: provider.provider_name,
    logoUrl: `${TMDB_IMAGE_BASE}/w45${provider.logo_path}`,
    ...getProviderLink(provider.provider_name, title)
  }));
}
function isHiddenProvider(name) {
  return !isAllowedProvider(name);
}
function deduplicateItems(items) {
  return [...new Map(items.map((item) => [item.id, item])).values()];
}
function compareItems(left, right) {
  return left.releaseDate.localeCompare(right.releaseDate) || left.title.localeCompare(right.title, "cs-CZ");
}
async function tmdbFetch(token, path) {
  let lastError;
  for (let attempt = 1; attempt <= REQUEST_ATTEMPTS; attempt += 1) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
    try {
      const response = await fetch(`${TMDB_API_BASE}${path}`, {
        headers: { Authorization: `Bearer ${token}`, Accept: "application/json" },
        signal: controller.signal
      });
      if (response.ok) {
        return await response.json();
      }
      const error = new Error(`TMDb ${path} failed with HTTP ${response.status}`);
      if (response.status < 500 || attempt === REQUEST_ATTEMPTS) {
        throw error;
      }
      lastError = error;
    } catch (error) {
      lastError = error;
      if (attempt === REQUEST_ATTEMPTS || error instanceof Error && /HTTP 4\d\d$/.test(error.message)) {
        throw error;
      }
    } finally {
      clearTimeout(timeout);
    }
    await new Promise((resolve) => setTimeout(resolve, 250 * 2 ** (attempt - 1)));
  }
  throw lastError;
}
async function mapConcurrent2(items, concurrency, mapper) {
  const results = new Array(items.length);
  let index = 0;
  async function worker() {
    while (index < items.length) {
      const currentIndex = index;
      index += 1;
      results[currentIndex] = await mapper(items[currentIndex]);
    }
  }
  await Promise.all(Array.from({ length: Math.min(concurrency, items.length) }, worker));
  return results;
}
function getPragueTodayISO() {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Europe/Prague",
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  }).formatToParts(/* @__PURE__ */ new Date());
  const values = Object.fromEntries(parts.map((part) => [part.type, part.value]));
  return `${values.year}-${values.month}-${values.day}`;
}
function getPragueNow() {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Europe/Prague",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23"
  }).formatToParts(/* @__PURE__ */ new Date());
  const values = Object.fromEntries(parts.map((part) => [part.type, part.value]));
  return {
    dateISO: `${values.year}-${values.month}-${values.day}`,
    time: `${values.hour}:${values.minute}`
  };
}
function parseISODate(value) {
  const date = /* @__PURE__ */ new Date(`${value}T00:00:00.000Z`);
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value) || Number.isNaN(date.getTime()) || date.toISOString().slice(0, 10) !== value) {
    throw new Error(`Invalid ISO date: ${value}`);
  }
  return date;
}
function startOfISOWeek(value) {
  const date = parseISODate(value);
  const dayOffset = (date.getUTCDay() + 6) % 7;
  date.setUTCDate(date.getUTCDate() - dayOffset);
  return date.toISOString().slice(0, 10);
}
function addDaysISO(value, days) {
  const date = parseISODate(value);
  date.setUTCDate(date.getUTCDate() + days);
  return date.toISOString().slice(0, 10);
}

// netlify/functions/refresh-radar.ts
async function handler(request) {
  const isBootstrap = request.headers.get("x-radar-bootstrap") === "1";
  if (!isPragueMidnight() && (!isBootstrap || await hasRadarCache())) {
    console.log("Skipping radar refresh outside Prague midnight");
    return new Response(null, { status: 204 });
  }
  try {
    const radar = await refreshRadarCache();
    console.log(`Radar cache refreshed at ${radar.fetchedAt} with ${radar.items.length} items`);
    return new Response(null, { status: 204 });
  } catch (error) {
    console.error("Radar refresh failed", error instanceof Error ? error.message : error);
    return new Response(JSON.stringify({ error: "Radar refresh failed" }), {
      status: error instanceof Error && error.message.includes("TMDB_API_TOKEN") ? 503 : 502,
      headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" }
    });
  }
}
function isPragueMidnight() {
  const hour = new Intl.DateTimeFormat("en-GB", {
    timeZone: "Europe/Prague",
    hour: "2-digit",
    hourCycle: "h23"
  }).format(/* @__PURE__ */ new Date());
  return hour === "00";
}
export {
  handler as default
};
